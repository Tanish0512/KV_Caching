
# tiny shakespeare

Tiny shakespeare, of the good old char-rnn fame :)

After running `prepare.py`:

- train.bin has 301,966 tokens
- val.bin has 36,059 tokens
